create database restaurant;

create table employees(
	id int not null,
	first_name char(50) not null,
	last_name char(50) not null,
	date_of_birth date not null,
	phone_number char(50), 
	position char(50),
	salary real
	);

create table orders(
	id int not null,
	employee_id int not null,
	list_of_dishes_id int not null,
	table_number int,
	date date
	);

create table dishes(
	id int not null,
	name char(50) not null,
	listofingredients_id int not null,
	price real not null,
	weight int
	);
	
create table menu(
	id int not null,
	name char(50) not null,
	listofdishes_id int not null
	);

create table cooked_dishes(
	id int not null,
	dish_id int not null,
	dish_name char(50) not null,
	employee_id int not null,
	order_id int not null,
	date date not null
	);

create table ingredients(
	id int not null,
	name char(50) not null
	);

create table storage(
	id int not null,
	ingredient_id int not null,
	ingredient_name char(50),
	amount int not null
	);

create table list_of_dishes(
	id int not null,
	dish_id_n1 int,
	dish_id_n2 int,
	dish_id_n3 int,
	dish_id_n4 int,
	dish_id_n5 int,
	dish_id_n6 int,
	dish_id_n7 int,
	dish_id_n8 int,
	dish_id_n9 int,
	dish_id_n10 int
	);

create table list_of_ingredients(
	id int not null,
	ingredient_id_n1 int,
	ingredient_id_n2 int,
	ingredient_id_n3 int,
	ingredient_id_n4 int,
	ingredient_id_n5 int,
	ingredient_id_n6 int,
	ingredient_id_n7 int,
	ingredient_id_n8 int,
	ingredient_id_n9 int,
	ingredient_id_n10 int
	);
    


	
	
