﻿INSERT INTO positions VALUES (1, 'waiter');
INSERT INTO positions VALUES (2, 'cook');
INSERT INTO positions VALUES (3, 'manager');
INSERT INTO positions VALUES (4, 'cleaner');

INSERT INTO employees VALUES (1, 'James', 'Loth', '18.01.1990', '0965482019', 1, 15000 );
INSERT INTO employees VALUES (2, 'Jon', 'Curis', '17.04.1984', '0508469576', 2, 10000 );
INSERT INTO employees VALUES (3, 'Ban', 'Trol', '25.09.1989', '0735224613', 1, 15000 );
INSERT INTO employees VALUES (4, 'Emma', 'Smith', '14.02.1994', '0996281419', 2, 8000 );
INSERT INTO employees VALUES (5, 'Marco', 'Polo', '09.11.1989', '0669102610', 2, 10000 );
INSERT INTO employees VALUES (6, 'Bred', 'Abrah', '15.04.1985', '0961445065', 3, 22000 );
INSERT INTO employees VALUES (7, 'Dirk', 'Nivic', '28.05.1994', '0732560420', 4, 6000 );
INSERT INTO employees VALUES (8, 'Viven', 'Aser', '11.08.1990', '0663885290', 4, 6000 );

INSERT INTO ingredients VALUES (1, 'potato');
INSERT INTO ingredients VALUES (2, 'carrot');
INSERT INTO ingredients VALUES (3, 'meat');
INSERT INTO ingredients VALUES (4, 'cabbage');
INSERT INTO ingredients VALUES (5, 'rice');
INSERT INTO ingredients VALUES (6, 'tomato');
INSERT INTO ingredients VALUES (7, 'cucambers');
INSERT INTO ingredients VALUES (8, 'coffee');
INSERT INTO ingredients VALUES (9, 'eggs');

INSERT INTO storage VALUES (1, 1, 10);
INSERT INTO storage VALUES (2, 2, 5);
INSERT INTO storage VALUES (3, 3, 7);
INSERT INTO storage VALUES (4, 4, 8);
INSERT INTO storage VALUES (5, 5, 5);
INSERT INTO storage VALUES (6, 6, 7);
INSERT INTO storage VALUES (7, 7, 8);
INSERT INTO storage VALUES (8, 8, 4);
INSERT INTO storage VALUES (9, 9, 5);

INSERT INTO list_of_ingredients VALUES (1, 1, 2, 3, 4);
INSERT INTO list_of_ingredients VALUES (2, 3, 5);
INSERT INTO list_of_ingredients VALUES (3, 3);
INSERT INTO list_of_ingredients VALUES (4, 1, 3);
INSERT INTO list_of_ingredients VALUES (5, 3, 5, 4);
INSERT INTO list_of_ingredients VALUES (6, 3, 6, 4, 7);
INSERT INTO list_of_ingredients VALUES (7, 9, 6, 3);
INSERT INTO list_of_ingredients VALUES (8, 1);

INSERT INTO menu VALUES (1, 'breakfast');
INSERT INTO menu VALUES (2, 'launch');
INSERT INTO menu VALUES (3, 'dinner');

INSERT INTO category_of_dishes VALUES (1, 'first course');
INSERT INTO category_of_dishes VALUES (2, 'garnish');
INSERT INTO category_of_dishes VALUES (3, 'main dishes');
INSERT INTO category_of_dishes VALUES (4, 'salads');

INSERT INTO dishes VALUES (1, 'borsh', 1, 1, 30, 300);
INSERT INTO dishes VALUES (2, 'pilaf', 2, 2, 30, 200);
INSERT INTO dishes VALUES (3, 'steak', 3, 3, 3, 200);
INSERT INTO dishes VALUES (4, 'pancakes with meat', 3, 4, 25, 400);
INSERT INTO dishes VALUES (5, 'cabbage rolls', 3, 5, 35, 300);
INSERT INTO dishes VALUES (6, 'salad with meat', 4, 6, 35, 300);
INSERT INTO dishes VALUES (7, 'scrambled eggs', 3, 7, 35, 300);
INSERT INTO dishes VALUES (8, 'mashed potato', 2, 8, 15, 300);

INSERT INTO list_of_dishes VALUES (1, 7);
INSERT INTO list_of_dishes VALUES (2, 1, 4);
INSERT INTO list_of_dishes VALUES (3, 3, 8, 6);









